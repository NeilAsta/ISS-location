

import json
import turtle
import urllib.request


url = 'http://api.open-notify.org/astros.json'
response = urllib.request.urlopen(url)
astros = json.loads(response.read())
print('People in space: ',astros['number'])
#print(astros)
people = astros['people']

for p in people:
    print(p['name'], 'in', p['craft'])
    
    url = 'http://api.open-notify.org/iss-now.json'
response = urllib.request.urlopen(url)
iss_now = json.loads(response.read())

location = iss_now['iss_position']
lat = float(location['latitude'])
lon = float(location['longitude'])
print('Latitude: ', lat)
print('Longitude: ', lon)

screen = turtle.Screen()
screen.bgpic('map.gif')
screen.setup(720, 360)
screen.setworldcoordinates(-180, -90, 180, 90)
screen.bgpic('map.gif')

screen = turtle.Screen()
screen.register_shape('iss2.gif')
iss = turtle.Turtle()
iss.shape('iss2.gif')
iss.setheading(90)
iss.penup()
iss.goto(lon, lat)

num_people = turtle.Turtle()
num_people.penup()
num_people.hideturtle()
num_people.color('yellow')
num_people.goto(-175,-25)
num_people.write('people in space: ' + str(astros['number']))

#turtle.write(str(astros['people']) + str(astros['craft']))
